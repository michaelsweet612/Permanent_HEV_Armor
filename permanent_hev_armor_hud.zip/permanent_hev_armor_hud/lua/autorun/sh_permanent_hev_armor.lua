--[[
    Permanent HEV Suit Armor HUD - Shared Autorun
    Ensures client scripts are properly sent over the network to connecting players.
]]

AddCSLuaFile("client/cl_permanent_hev_armor.lua")
